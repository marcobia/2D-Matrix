#include "CMatrix.h"
#include <iostream>
#include <assert.h>


CMatrix::CMatrix(int r, int c) : rows(r), cols(c) {
	// Storage allocation
	array = new int *[r]; 		//initialize empty rows
	assert(array);
	for(int i = 0; i < r; i++){
		array[i] = new int[c]; // initialize empty columns
		assert(array[i]);
	}
	
	// Matrix values intialization
	for (int i=0; i<r; i++) {
		for (int j=0; j<c; j++){
			 array[i][j]  = 0;
		}
	}    
}

//copy constructor
CMatrix::CMatrix(const CMatrix &rhs){
    cols = rhs.cols;
    rows = rhs.rows;
    array = new int * [rhs.rows];
    assert(array);
    for(int i=0;i<rhs.rows;i++){
       array[i] = new int[rhs.cols];
       assert(array[i]);
    }
    for(int i=0;i<rhs.rows;i++)
      for(int j=0;j<rhs.cols;j++)
            array[i][j]=rhs[i][j];
}

//destructor
CMatrix::~CMatrix(){ //destroy matrix
//	std::cout << "Destructor called." << std::endl;
	for (int i=0; i<rows; i++){
		delete[] array[i]; //delete columns
		}
	delete[] array; //delete rows
};

//=======================================
//    FUNCTIONS
//=======================================

void CMatrix::print(){
	for (int i=0; i<rows; i++){
		for (int j=0; j<cols; j++){
			 std::cout << array[i][j]  << " ";
		}
		std::cout << std::endl;
	}
}

void CMatrix::zeros(){
	for (int i=0; i<rows; i++){
		for (int j=0; j<cols; j++){
			array[i][j] = 0;
		}
	}
}

void CMatrix::ones(){
	for (int i=0; i<rows; i++){
		for (int j=0; j<cols; j++){
			array[i][j] = 1;
		}
	}
}

void CMatrix::sequence(){
	int k = 1;
	for (int i=0; i<rows; i++){
		for (int j=0; j<cols; j++){
			array[i][j] = k;
			k++;
		}
	}
}

CMatrix CMatrix::trans () {
	CMatrix temp (cols,rows);
	for (int i=0; i<rows; i++){
		for (int j=0; j<cols; j++){
			 temp.array[j][i] = array[i][j];
		}
	}
	return temp;
}


//=====================================================
//       OVERLOAD OPERATORS
//=====================================================

CMatrix& CMatrix::operator= (const CMatrix& rhs){ 
	for (int i=0; i<rows; i++)
		for (int j=0; j<cols; j++)
        	array[i][j] = rhs.array[i][j];
}

// Overload operator []
int* & CMatrix::operator [](const int &index) const { 
   		return  array [index];
	}
	
// Overload operator* for Scalar moltiplication
CMatrix CMatrix::operator* (const int& val){ //int
	CMatrix temp (rows,cols);
	for (int i=0; i<rows; i++){
		for (int j=0; j<cols; j++){
			 temp.array[i][j] = array[i][j] * val;
		}
	}
	return temp;
}

// Overload operator* for Matrix moltiplication (row-times-column)
CMatrix CMatrix::operator* (const CMatrix& rhs) const {
	if (cols==rhs.rows)	{
		CMatrix temp (rows, rhs.cols);
		for (int i=0; i<rows; i++)
			for (int j=0; j<rhs.cols; j++)
				for (int k=0; k<cols; k++)
					temp.array[i][j] += array[i][k] * rhs.array[k][j];		
		return temp;
	}
	else{
		std::cout << "! ! ! ! ! ! ! ! ! ! ! ! ! ! ! ! ! ! ! ! ! ! ! ! " << std::endl;
		std::cout << "Incorrect dimensions for matrix multiplication:" << std::endl;
		std::cout << "Left matrix: [" << rows << "x" << cols <<"]" << std::endl;
		std::cout << "Right matrix: [" << rhs.rows << "x" << rhs.cols << "]" << std::endl;
		std::cout << "! ! ! ! ! ! ! ! ! ! ! ! ! ! ! ! ! ! ! ! ! ! ! ! " << std::endl;
		CMatrix temp (rows, cols);
    	return temp;
	}
}

// Overload operator+ for Matrix addition
CMatrix CMatrix::operator+ (const CMatrix& rhs) {
	
	CMatrix temp (rows,cols);
	if (rows==rhs.rows && cols==rhs.cols){
		for (int i=0; i<rows; i++){
			for (int j=0; j<cols; j++){
				 temp.array[i][j] = array[i][j] + rhs.array[i][j];
			}
		}
		return temp;
	}
	else{
		std::cout << "Incorrect dimensions for matrix addition." << std::endl;
		std::cout << "Left matrix: [" << rows << "x" << cols <<"]" << std::endl;
		std::cout << "Right matrix: [" << rhs.rows << "x" << rhs.cols << "]" << std::endl;
		CMatrix temp (rows, cols);
    	return temp;
	}
}

// overload operator+ for Scalar addiion
CMatrix CMatrix::operator+ (const int& val){ //int
	CMatrix temp (rows,cols);
	for (int i=0; i<rows; i++){
		for (int j=0; j<cols; j++){
			 temp.array[i][j] = array[i][j] + val;
		} 
	}
	return temp;
}

// Overload operator- for Matrix addition
CMatrix CMatrix::operator- (const CMatrix& rhs) {
	
	CMatrix temp (rows,cols);
	if (rows==rhs.rows && cols==rhs.cols){
		for (int i=0; i<rows; i++){
			for (int j=0; j<cols; j++){
				 temp.array[i][j] = array[i][j] - rhs.array[i][j];
			}
		}
		return temp;
	}
	else{
		std::cout << "Incorrect dimensions for matrix addition." << std::endl;
		std::cout << "Left matrix: [" << rows << "x" << cols <<"]" << std::endl;
		std::cout << "Right matrix: [" << rhs.rows << "x" << rhs.cols << "]" << std::endl;
		CMatrix temp (rows, cols);
    	return temp;
	}
}

// overload operator+ for Scalar addiion
CMatrix CMatrix::operator- (const int& val){ //int
	CMatrix temp (rows,cols);
	for (int i=0; i<rows; i++){
		for (int j=0; j<cols; j++){
			 temp.array[i][j] = array[i][j] - val;
		} 
	}
	return temp;
}

