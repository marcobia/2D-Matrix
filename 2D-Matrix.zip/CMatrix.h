#ifndef CMATRIX_H
#define CMATRIX_H
#include <iostream>
#include <assert.h>


class CMatrix {
private:
	
public:
	int rows,cols;
	int ** array;
	
	CMatrix (int, int); // Constructor
	CMatrix(const CMatrix& ); //constructor to copy a matrix
	~CMatrix(); //destructor

	// Functions
	void print(); //initialize the matrix
	void zeros(); //initialize the matrix to zeros
	void ones(); //initialize the matrix to ones
	void sequence(); //initialize the matrix with a unit-spaced sequnece of numbers starting from '1'
	int getRows(){return rows;}
    int getCols(){return cols;}
    CMatrix trans(); // Transposed matrix
	
	// Overload operatos
	CMatrix& operator= (const CMatrix& m);
	int* & operator [](const int &index) const;
	CMatrix operator* (const int& val);
	CMatrix operator* (const CMatrix& rhs) const;	
	CMatrix operator+ (const CMatrix&);
	CMatrix operator+ (const int& val);
	CMatrix operator- (const CMatrix&);
	CMatrix operator- (const int& val);
};

#endif // CMATRIX_H 
