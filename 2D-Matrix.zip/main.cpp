#include "CMatrix.h"
#include <iostream>
#include <assert.h>


int main(int argc, char** argv) {
	
	int k = 1;
	CMatrix M1 (3,4); M1.ones();
	CMatrix M2 (3,4); M2.ones();
	CMatrix M3 (3,4); 
	CMatrix M4 (4,3); M4.sequence();
	CMatrix M5 (3,3);
	CMatrix M6 (4,7); 
	CMatrix M7 (3,7);
	
	std::cout << "========================================="<< std::endl;
	std::cout << "         TC" << k << " - matrix addition"<< std::endl;
	std::cout << "========================================="<< std::endl;
    std::cout << std::endl;
    k++;
    
    std::cout << "M1:"<< std::endl;
    M1.print();
    std::cout << std::endl;
    
    std::cout << "M2:"<< std::endl;
    M2.print();
    std::cout << std::endl;
    
    std::cout << "M3 = M1 + M2:"<< std::endl;
    M3 = M1 + M2;
    M3.print();
    std::cout << std::endl;
    
    std::cout << "========================================="<< std::endl;
	std::cout << "         TC" << k << " - scalar addition"<< std::endl;
	std::cout << "========================================="<< std::endl;
	std::cout << std::endl;
	k++;
	
    std::cout << "M1:"<< std::endl;
    M1.print();
    std::cout << std::endl;
    
    std::cout << "M2 = M1 + 3:"<< std::endl;
    M2 = M1 + 3;
    M2.print();
    std::cout << std::endl;
    
    std::cout << "========================================="<< std::endl;
	std::cout << "         TC" << k << " - matrix subtraction"<< std::endl;
	std::cout << "========================================="<< std::endl;
    std::cout << std::endl;
    k++;
    
    std::cout << "M1:"<< std::endl;
    M1.print();
    std::cout << std::endl;
    
    std::cout << "M2:"<< std::endl;
    M2.print();
    std::cout << std::endl;
    
    std::cout << "M3 = M1 - M2:"<< std::endl;
    M3 = M1 - M2;
    M3.print();
    std::cout << std::endl;
    
    std::cout << "========================================="<< std::endl;
	std::cout << "         TC" << k << " - scalar subtraction"<< std::endl;
	std::cout << "========================================="<< std::endl;
	std::cout << std::endl;
	k++;
	
    std::cout << "M1:"<< std::endl;
    M1.print();
    std::cout << std::endl;
    
    std::cout << "M2 = M1 - 3:"<< std::endl;
    M2 = M1 - 3;
    M2.print();
    std::cout << std::endl;
    
    std::cout << "========================================="<< std::endl;
	std::cout << "         TC" << k << " - matrix moltiplication"<< std::endl;
	std::cout << "          [3x3] = [3x4] * [4x3]"<< std::endl;
	std::cout << "========================================="<< std::endl;
	std::cout << std::endl;
	k++;
	
	std::cout << "M2:"<< std::endl;
	M2.sequence();
    M2.print();
    std::cout << std::endl;
    
    std::cout << "M4:"<< std::endl;
    M4.print();
    std::cout << std::endl;
    
    std::cout << "M5 = M2 * M4:"<< std::endl;
    M5 = M2 * M4;
    M5.print();
    std::cout << std::endl;
    std::cout << "Expected: [3x3] = [3x4] * [4x3] :"<< std::endl;
    if (M5.getRows() == 3 && M5.getCols() == 3)
    	std::cout << "Actual: [" << M5.getRows() << "x"<<M5.getCols()<<"]        --PASSED"<< std::endl;
    else
    	std::cout << "Actual: [" << M5.getRows() << "x"<<M5.getCols()<<"]        --FAIL"<< std::endl;
    std::cout << std::endl;
    
    std::cout << "========================================="<< std::endl;
	std::cout << "         TC" << k << " - matrix moltiplication"<< std::endl;
	std::cout << "          [3x7] = [3x4] * [4x7]"<< std::endl;
	std::cout << "========================================="<< std::endl;
	std::cout << std::endl;
	k++;
	
	std::cout << "M2:"<< std::endl;
	M2.sequence();
    M2.print();
    std::cout << std::endl;
    
    std::cout << "M6:"<< std::endl;
    M6.sequence();
    M6.print();
    std::cout << std::endl;
    
    std::cout << "M7 = M2 * M6"<< std::endl;
    M7 = M2 * M6;
    M7.print();
    std::cout << std::endl;
    std::cout << "Expected: [3x7] = [3x4] * [4x7] :"<< std::endl;
    if (M7.getRows() == 3 && M7.getCols() == 7)
    	std::cout << "Actual: [" << M7.getRows() << "x"<<M7.getCols()<<"]        --PASSED"<< std::endl;
    else
    	std::cout << "Actual: [" << M7.getRows() << "x"<<M7.getCols()<<"]        --FAIL"<< std::endl;
    std::cout << std::endl;
    
    std::cout << "========================================="<< std::endl;
	std::cout << "         TC" << k << " - matrix moltiplication"<< std::endl;
	std::cout << "          ERROR: [?] = [3x4] * [3x4]"<< std::endl;
	std::cout << "========================================="<< std::endl;
	std::cout << std::endl;
	k++;
	
	std::cout << "M2 [3x4]:"<< std::endl;
	M2.sequence();
    M2.print();
    std::cout << std::endl;
    
    std::cout << "M3 [3x4]:"<< std::endl;
    M4.print();
    std::cout << std::endl;
    
    std::cout << "M5 = M2 * M3:"<< std::endl;
    std::cout << "[?] = [3x4] * [3x4] :"<< std::endl;
    M5 = M2 * M3;
    std::cout << std::endl;
    
    std::cout << "========================================="<< std::endl;
	std::cout << "         TC" << k << " - scalar moltiplication"<< std::endl;
	std::cout << "========================================="<< std::endl;
	std::cout << std::endl;
	k++;
	
    std::cout << "M1:"<< std::endl;
    M1.ones();
    M1.print();
    std::cout << std::endl;
    
    std::cout << "M2 = M1 * 3 :"<< std::endl;
    M2 = M1 * 3;
    M2.print();
    std::cout << std::endl;
    
    std::cout << "========================================="<< std::endl;
	std::cout << "         TC" << k << " - Matrix duplicate"<< std::endl;
	std::cout << "========================================="<< std::endl;
	std::cout << std::endl;
	k++;
	
    std::cout << "M1:"<< std::endl;
    M1.print();
    std::cout << std::endl;
    
    std::cout << "M2:"<< std::endl;
    M2.sequence();
    M2.print();
    std::cout << std::endl;
    
    std::cout << "M2 = M1:"<< std::endl;
    M2 = M1;
    M2.print();
    std::cout << std::endl;
    
    std::cout << "========================================="<< std::endl;
	std::cout << "         TC" << k << " - Assign value"<< std::endl;
	std::cout << "========================================="<< std::endl;
	std::cout << std::endl;
	k++;
	
	std::cout << "M1:"<< std::endl;
	M1.ones();
    M1.print();
    std::cout << std::endl;
    
    std::cout << "Assign value '23' to M1[1][1] :"<< std::endl;
    int val = 23;
    int n = 1;
    int m = 1;
    
    M1[n][m] = val;
    M1.print();
    std::cout << std::endl;
    
    if (M1[n][m] == val)
		std::cout << "M1[" << n << "][" << m << "] = " << val << "    --PASSED" << std::endl;
	else
		std::cout << "M1[" << n << "][" << m << "] != " << val << "     --FAIL" << std::endl;
    std::cout << std::endl;
    
    std::cout << "========================================="<< std::endl;
	std::cout << "         TC" << k << " - Get value" << std::endl;
	std::cout << "========================================="<< std::endl;
	std::cout << std::endl;
	k++;
    
	std::cout << "M1:"<< std::endl;
	M1.print();
	std::cout << std::endl;
	
	std::cout << "val = M1[1][1]:"<< std::endl;
	val=0;
	val = M1[1][1];
	std::cout << std::endl;
	if (val == 23)
		std::cout << "val = " << val << "      --PASSED" << std::endl;
	else
		std::cout << "val != " << val << "       --PASSED" << std::endl;
	std::cout << std::endl;
	
	std::cout << "========================================="<< std::endl;
	std::cout << "         TC" << k << " - Transposed matrix" << std::endl;
	std::cout << "========================================="<< std::endl;
	std::cout << std::endl;
	k++;
    
	std::cout << "M1:"<< std::endl;
	M1.sequence();
	M1.print();
	std::cout << std::endl;
	
	std::cout << "M4 = M1':"<< std::endl;
	M4 = M1.trans();
	M4.print();
	std::cout << std::endl;
	
	return 0;
}
